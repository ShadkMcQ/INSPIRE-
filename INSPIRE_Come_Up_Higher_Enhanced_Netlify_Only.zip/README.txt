INSPIRE — COME UP HIGHER | NETLIFY-ONLY ENHANCED EDITION

Includes: reflection, word cloud, open-text or choice polls, quiz scoring (1 point per correct answer), Q&A upvoting, CSV export, open facilitator dashboard, presentation screen, and personal notes.

DEPLOY: Extract ZIP; upload files to a GitHub repository; in Netlify choose Add new project > Import from Git > GitHub, select the repository. Build command: leave blank. Publish directory: . (dot). Netlify installs the dependency in package.json and deploys the Functions automatically.

Participant: https://YOUR-SITE.netlify.app/
Facilitator: https://YOUR-SITE.netlify.app/?view=facilitator
Presentation: https://YOUR-SITE.netlify.app/?view=screen

NO SUPABASE. Netlify Blobs stores shared event and response data. No facilitator password is required. SECURITY WARNING: facilitator page is intentionally NOT AUTHENTICATED. Anyone who knows the facilitator URL can access responses, edit questions and delete data. The URL is easy to guess, so do not use this version for sensitive or confidential reflections. For real privacy, enable authentication before using with real people.

The facilitator first opens their dashboard to initialize the event. Quiz: enter choices and a 1-based correct-choice number, or leave choices empty and enter the exact correct text answer. Polls may have zero, one or more choices. Q&A upvotes are one per participant/browser identifier (not tamper-proof). Quiz scores are per question, with a cumulative leaderboard in the facilitator dashboard. CSV exports include score and upvotes.

Netlify's serverless Functions and Blobs require a Git-based deployment (or CLI deployment). Drag-and-drop static hosting alone will NOT deploy the backend. The app refreshes periodically. Netlify usage limits apply. This code has been syntax-checked but not live-tested on your Netlify account.
